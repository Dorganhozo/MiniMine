package com.minimine;

public class Mundo {
	
}
